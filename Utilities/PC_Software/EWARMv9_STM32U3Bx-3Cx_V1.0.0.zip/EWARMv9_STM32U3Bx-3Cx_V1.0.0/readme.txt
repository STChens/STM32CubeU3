/**
  *************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U3Bxx_Cxx devices support on EWARM.
  *************************************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************/
  
 Package general purpose:
  ==================================================================================================================================	
  These packages contains the needed files to be installed in order to support STM32U3Bxx_Cxx 
  devices by EWARM9 and laters.
  
  We inform you that this package is suitable for internal & external use.
  EWARMv9_STM32U3Bx-3Cx_V1.0.0.exe has been digitally signed by STMicroelectronics.
  
  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  ===================================================================================================================================  
	1. If you have previously installed an STM32 patch, it will be removed during the first run. 
	2. The following items will be added :
		- Part numbers with 2MB Flash size : STM32U3B5xI/U3C5xI.
		- Part numbers with 1MB Flash size : STM32U3B5xG.
		
		- Automatic internal Flash loader selection.
  
    3. The following SVD files will be added:
		- STM32U3B5 & STM32U3C5 SVD files v1.0.

PS: When using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.
    That you can run EWARMv9_STM32U3Bx-3Cx_V1.0.0.exe only if the uninstall is not needed.

 How to use:
 ====================================================================================================================================
 * Before installing the files mentioned above, you need to have EWARM v9.20.1 or later installed. 
 
  You can download EWARM from IAR web site @ www.iar.com
 
 * Run "EWARMv9_STM32U3Bx-3Cx_V1.0.0.exe" or using the "Install_Patch.bat" as administrator on EWARM install directory.
   Ewarm Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \".
   Please change it manually if you have EWARM installed at a different location.   


 SVD files ReleaseNotes:
 ====================================================================================================================================
	=======================================================
	STM32U3_v1r2:
	=======================================================
	V1.0   First release
	V1.1   Update in GTZC1_TZIC peripheral for U3
	V1.2   Adding support for STM32U3B5 and U3C5