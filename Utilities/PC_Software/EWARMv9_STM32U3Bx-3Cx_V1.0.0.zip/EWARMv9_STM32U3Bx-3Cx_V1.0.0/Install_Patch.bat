@echo off
setlocal

echo "Uninstall the old EWARMv9_STM32U3Bx-Cx patch."
echo "Please select the folder where the old patch needs to be removed."

setlocal enabledelayedexpansion

set "psCommand=Add-Type -AssemblyName System.Windows.Forms; $fileBrowser = New-Object System.Windows.Forms.OpenFileDialog; $fileBrowser.Filter = 'Folders|*.none'; $fileBrowser.CheckFileExists = $false; $fileBrowser.FileName = 'Select Folder'; if ($fileBrowser.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { [System.IO.Path]::GetDirectoryName($fileBrowser.FileName) }"

for /f "usebackq delims=" %%I in (`powershell -NoProfile -Command "%psCommand%"`) do set "folder=%%I"

:: Check if the folder was selected
if "!folder!"=="" (
    echo No folder was selected.
    exit /b 1
)

:: Check if the folder exists
if not exist "!folder!" (
    echo The folder "!folder!" does not exist.
    exit /b 1
)

:: List of folders to search and delete
set "foldersToDelete=STM32U3B5 STM32U3C5"

:: Loop through each folder name and search for it recursively
for %%F in (%foldersToDelete%) do (
    for /f "delims=" %%D in ('dir /b /s /ad "!folder!\%%F" 2^>nul') do (
        if exist "%%D" (
            echo Deleting folder: "%%D"
            rmdir /S /Q "%%D"
        )
    )
)

endlocal

echo "Install the new EWARMv9_STM32U3Bx-Cx patch"
echo "Please choose the folder in which you want to install the patch"
setlocal enabledelayedexpansion
set "current_path=%cd%"
start  /wait /d "%current_path%" EWARMv9_STM32U3Bx-3Cx_V1.0.0.exe



echo "The README file is currently being opened."
start readme.txt

:LOOP
IF NOT EXIST readme.txt (
    TIMEOUT /T 1 /NOBREAK
    GOTO LOOP
)

endlocal
pause	