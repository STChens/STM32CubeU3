**
  *******************************************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U3xx devices support on MDK-ARM.
  *******************************************************************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *******************************************************************************************************************************
  
  Package general purpose:
  ===============================================================================================================================
	These packages contains the needed files to be installed in order to support STM32U3 devices by MDK-ARM v5.25 and laters.

	We inform you that this package is suitable for internal & external use.
  
  Running the "Keil.STM32U3xx_DFP.1.2.0.pack" adds the following: 
  ================================================================================================================================ 
   1. Part numbers for  :
   - Product with 2MB Flash size: STM32U3B5xIxx/STM32U3C5xIxx.
   - Product with 1MB Flash size: STM32U375xGxx/STM32U385xGxx/STM32U3B5xGxx.
   - Product with 512kB Flash size: STM32U375xExx
   
   - Automatic STM32U3xx internal secure & nnsecure flash algorithm selection   
   
   2. The following SVD files will be added:
   - STM32U375, STM32U385, STM32U3B5 & STM32U3C5 SVD file V1.2.


  How to use:
 =================================================================================================================================
	* Before installing the files mentioned above, you need to have MDK-ARM v5.25 
	  or later installed. 
	  You can download pack from keil web site @ www.keil.com
 
	* Double Clic on  "Keil.STM32U3xx_DFP.1.2.0.pack" in order to install this pack in 
	  the Keil install directory.
	
	PS: Please make sure that you are using PackUnzip.exe to run this pack.
 
 
 SVD files ReleaseNotes:
 ==================================================================================================================================
	V1.0   First release
    V1.1   Update in GTZC1_TZIC peripheral for U3
    V1.2   Adding support for STM32U3B5 and U3C5
	
	
	